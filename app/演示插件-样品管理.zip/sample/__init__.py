# -*- coding: utf-8 -*-
"""演示插件：样品管理
用于体验平台的插件生命周期：上传安装 → 启停 → 卸载。
插件自己管理数据表（sample_records）与工作流程，平台只负责接管登录/权限/导航/启停/表登记。
"""
import sqlite3
from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, g, session

blueprint = Blueprint('sample', __name__, template_folder='templates')

manifest = {
    'id': 'sample',
    'name': '样品管理',
    'icon': '📦',
    'group': '业务插件',
    'core': False,
    'description': '演示插件：样品登记与查询，用于体验插件的启停/卸载',
    'endpoint': 'sample.index',
    'tables': ['sample_records'],
    'url_prefix': '/sample',
}


def get_db():
    """插件自己的数据管理：与平台共用 business.db，但表空间独立（sample_records 归本插件）"""
    from flask import current_app
    db = getattr(g, '_sample_db', None)
    if db is None:
        db = sqlite3.connect(current_app.config['DATABASE'])
        db.row_factory = sqlite3.Row
        db.execute('''CREATE TABLE IF NOT EXISTS sample_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            model TEXT DEFAULT '',
            qty INTEGER DEFAULT 1,
            remark TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now','localtime'))
        )''')
        db.commit()
        g._sample_db = db
    return db


@blueprint.teardown_app_request
def _close(e):
    db = getattr(g, '_sample_db', None)
    if db is not None:
        db.close()


@blueprint.route('/sample')
def index():
    db = get_db()
    rows = db.execute('SELECT * FROM sample_records ORDER BY id DESC').fetchall()
    return render_template('sample_index.html', rows=rows)


@blueprint.route('/sample/add', methods=['POST'])
def add():
    db = get_db()
    name = (request.form.get('name') or '').strip()
    if not name:
        flash('请填写样品名称', 'error')
        return redirect(url_for('sample.index'))
    db.execute('INSERT INTO sample_records (name, model, qty, remark) VALUES (?,?,?,?)',
               (name, (request.form.get('model') or '').strip(),
                int(request.form.get('qty') or 1), (request.form.get('remark') or '').strip()))
    db.commit()
    flash(f'样品「{name}」已登记', 'success')
    return redirect(url_for('sample.index'))


@blueprint.route('/sample/del/<int:sid>', methods=['POST'])
def delete(sid):
    db = get_db()
    db.execute('DELETE FROM sample_records WHERE id=?', (sid,))
    db.commit()
    flash('样品记录已删除', 'info')
    return redirect(url_for('sample.index'))
